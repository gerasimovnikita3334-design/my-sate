import { useState, useEffect } from "react";

const MAX_LINK = "https://max.ru/u/f9LHodD0cOI78EgUmEOKIRXZPUPx4II_oniyYw0XBgpwDx0ZEu4VMprTraI";
const TG_LINK  = "https://t.me/Lonyyyvip";

const pairs = [
  { sym:"EUR/USD", val:"1.0874", chg:"+0.12%", up:true,  pts:"0,28 14,22 28,24 42,14 56,18 70,10 84,13 98,5"  },
  { sym:"GBP/USD", val:"1.2738", chg:"+0.08%", up:true,  pts:"0,26 14,20 28,22 42,12 56,16 70,8  84,11 98,3"  },
  { sym:"USD/JPY", val:"149.32", chg:"-0.21%", up:false, pts:"0,4  14,9  28,7  42,16 56,12 70,20 84,17 98,26" },
  { sym:"XAU/USD", val:"2318.4", chg:"+0.54%", up:true,  pts:"0,28 14,22 28,18 42,12 56,15 70,7  84,9  98,2"  },
  { sym:"BTC/USD", val:"67 420", chg:"+2.31%", up:true,  pts:"0,30 14,24 28,20 42,10 56,14 70,6  84,8  98,1"  },
  { sym:"ETH/USD", val:"3 512",  chg:"+1.77%", up:true,  pts:"0,28 14,21 28,17 42,11 56,15 70,7  84,9  98,2"  },
];

const modules = [
  { n:"01", title:"Основы Форекс",       desc:"Как работает рынок, валютные пары, торговые сессии, пипсы, лоты и кредитное плечо." },
  { n:"02", title:"Технический анализ",  desc:"Свечные паттерны, уровни поддержки/сопротивления, трендовые линии и фигуры." },
  { n:"03", title:"Индикаторы",          desc:"RSI, MACD, Bollinger Bands, EMA — как читать и правильно комбинировать сигналы." },
  { n:"04", title:"Риск-менеджмент",     desc:"Стоп-лоссы, тейк-профиты, управление капиталом и правило 1–2% от депозита." },
  { n:"05", title:"Торговые стратегии",  desc:"Скальпинг, интрадей, свинг — готовые стратегии с реальными примерами входов." },
  { n:"06", title:"Психология трейдера", desc:"FOMO, дисциплина, управление эмоциями — самое важное для стабильного дохода." },
];

const faqs = [
  { q:"Это бесплатно?",                 a:"100%. Никаких скрытых платежей, подписок или VIP-доступов. Всё абсолютно бесплатно." },
  { q:"Я полный новичок — подойдёт?",   a:"Именно для тебя. Напиши мне — скажу с какого модуля начать и дам материалы в нужном порядке." },
  { q:"Нужен стартовый капитал?",       a:"Нет. Начинаем на демо-счёте — учимся без риска потерять реальные деньги." },
  { q:"Сколько времени займёт?",        a:"Базу можно освоить за 3–4 недели при занятиях 1–2 часа в день." },
];

/* ── sparkline ── */
function Spark({ pts, up }: { pts: string; up: boolean }) {
  const color = up ? "#00ff88" : "#ff3b3b";
  return (
    <svg viewBox="0 0 98 32" className="w-16 h-5" preserveAspectRatio="none">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.8"
        strokeLinecap="round" strokeLinejoin="round" opacity=".9" />
    </svg>
  );
}

/* ── area chart ── */
function AreaChart() {
  const pts = [[0,88],[50,72],[100,78],[150,55],[200,50],[250,30],[300,38],[350,18],[400,12]];
  const line = pts.map(([x,y],i)=>`${i?"L":"M"}${x},${y}`).join(" ");
  const area = line+` L400,100 L0,100 Z`;
  return (
    <svg viewBox="0 0 400 100" className="w-full h-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="ag" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#00ff88" stopOpacity=".22"/>
          <stop offset="100%" stopColor="#00ff88" stopOpacity="0"/>
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>
      {[25,50,75].map(y=>(
        <line key={y} x1="0" y1={y} x2="400" y2={y} stroke="#1c1c1c" strokeWidth="1"/>
      ))}
      <path d={area} fill="url(#ag)"/>
      <path className="line-draw" d={line} fill="none" stroke="#00ff88"
        strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" filter="url(#glow)"/>
      {/* last dot */}
      <circle cx="400" cy="12" r="4" fill="#00ff88" filter="url(#glow)"/>
      <circle cx="400" cy="12" r="9" fill="#00ff88" opacity=".15" className="blink"/>
    </svg>
  );
}

/* ── animated counter ── */
function Counter({ to, suffix="" }: { to: number; suffix?: string }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = to / 40;
    const id = setInterval(() => {
      start += step;
      if (start >= to) { setVal(to); clearInterval(id); }
      else setVal(Math.floor(start));
    }, 30);
    return () => clearInterval(id);
  }, [to]);
  return <>{val.toLocaleString("ru-RU")}{suffix}</>;
}

/* ── faq item ── */
function Faq({ q, a }: { q:string; a:string }) {
  const [open, setOpen] = useState(false);
  return (
    <button
      onClick={() => setOpen(!open)}
      className="w-full text-left border-b border-[#1c1c1c] group focus:outline-none"
    >
      <div className="flex items-center justify-between py-5 gap-6">
        <span className="font-sans font-medium text-white text-sm md:text-base">{q}</span>
        <span
          className="text-[#00ff88] text-2xl font-light shrink-0 transition-transform duration-300 leading-none"
          style={{ transform: open ? "rotate(45deg)" : "rotate(0)" }}
        >+</span>
      </div>
      {open && <p className="text-[#555] text-sm leading-relaxed pb-5">{a}</p>}
    </button>
  );
}

/* ── logo ── */
function Logo({ size = "md" }: { size?: "sm" | "md" }) {
  const small = size === "sm";
  return (
    <div className={`flex items-center gap-${small?"2":"2.5"}`}>
      <svg
        className={small ? "w-4 h-4 text-[#00ff88]" : "w-5 h-5 text-[#00ff88]"}
        viewBox="0 0 20 20" fill="none" stroke="currentColor"
        strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
      >
        <polyline points="1,16 6,9 11,12 19,3"/>
      </svg>
      <span className={`font-display tracking-wider text-white ${small?"text-base":"text-xl"}`}>
        LONY<span className="text-[#00ff88]">FX</span>
      </span>
    </div>
  );
}

export default function App() {
  const [navBg, setNavBg] = useState(false);
  useEffect(() => {
    const fn = () => setNavBg(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <div className="min-h-full bg-black text-white overflow-x-hidden">

      {/* NAV */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          navBg ? "border-b border-[#1c1c1c] bg-black/95 backdrop-blur-md" : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-5 md:px-12 h-14 flex items-center justify-between">
          <Logo/>
          <div className="hidden md:flex items-center gap-9 font-mono text-[10px] text-[#444] uppercase tracking-[.18em]">
            {["Программа","О курсе","FAQ","Контакт"].map(t=>(
              <a key={t} href={`#${t.toLowerCase()}`}
                className="hover:text-[#00ff88] transition-colors duration-200">{t}</a>
            ))}
          </div>
          <a href={TG_LINK} target="_blank" rel="noopener noreferrer"
            className="font-mono text-[11px] text-black bg-[#00ff88] px-5 py-2.5 tracking-widest uppercase hover:bg-white transition-colors duration-200">
            Начать →
          </a>
        </div>
      </nav>

      {/* ══ HERO ══ */}
      <section className="hero-grid relative min-h-screen flex flex-col pt-14">
        {/* top corner accent */}
        <div className="absolute top-14 right-0 w-px h-32 bg-gradient-to-b from-[#00ff88] to-transparent opacity-40"/>
        <div className="absolute top-14 right-0 w-32 h-px bg-gradient-to-l from-[#00ff88] to-transparent opacity-40"/>

        <div className="max-w-7xl mx-auto px-5 md:px-12 w-full flex-1 grid md:grid-cols-[1fr_420px] lg:grid-cols-[1fr_480px] gap-10 items-center py-16">

          {/* left */}
          <div>
            <div className="fade-up flex items-center gap-2.5 mb-8" style={{animationDelay:".05s"}}>
              <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] blink"/>
              <span className="font-mono text-[#00ff88] text-[10px] uppercase tracking-[.22em]">
                Бесплатное обучение · Форекс
              </span>
            </div>

            <h1
              className="fade-up font-display leading-[.88] tracking-wider mb-10"
              style={{fontSize:"clamp(72px,13vw,180px)", animationDelay:".12s"}}
            >
              СТАНЬ<br/>
              <span className="text-[#00ff88]">ТРЕЙДЕ</span><br/>
              <span className="text-[#00ff88]">РОМ</span>
            </h1>

            <p className="fade-up text-[#555] text-sm md:text-base leading-relaxed max-w-sm mb-10"
               style={{animationDelay:".22s"}}>
              Практическое обучение с нуля — стратегии, риск-менеджмент, торговое мышление. Без воды. Бесплатно.
            </p>

            <div className="fade-up flex flex-wrap gap-3" style={{animationDelay:".3s"}}>
              <a href={TG_LINK} target="_blank" rel="noopener noreferrer"
                className="btn-glow inline-flex items-center gap-2.5 bg-[#00ff88] text-black font-bold text-sm px-7 py-3.5 hover:bg-white transition-colors duration-200">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.1 13.137 4.17 12.26c-.657-.204-.669-.657.136-.975l10.97-4.23c.547-.194 1.026.13.618.166z"/>
                </svg>
                Telegram
              </a>
              <a href={MAX_LINK} target="_blank" rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 border border-[#2a2a2a] text-[#888] text-sm px-7 py-3.5 hover:border-[#00ff88] hover:text-[#00ff88] transition-colors duration-200">
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20 2H4C2.9 2 2 2.9 2 4v16l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
                </svg>
                MAX
              </a>
            </div>
          </div>

          {/* right – terminal card */}
          <div className="slide-right border border-[#1c1c1c] bg-[#050505] overflow-hidden">
            {/* terminal bar */}
            <div className="flex items-center gap-2 px-4 py-3 border-b border-[#1c1c1c] bg-[#080808]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff3b3b] opacity-70"/>
              <span className="w-2.5 h-2.5 rounded-full bg-[#ffbb00] opacity-70"/>
              <span className="w-2.5 h-2.5 rounded-full bg-[#00ff88] opacity-70"/>
              <span className="font-mono text-[#333] text-[10px] ml-2 tracking-wider">EUR/USD · 1H · LIVE</span>
              <span className="ml-auto flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] blink"/>
                <span className="font-mono text-[10px] text-[#00ff88]">LIVE</span>
              </span>
            </div>

            {/* price row */}
            <div className="px-5 pt-5 pb-3 flex items-start justify-between">
              <div>
                <div className="font-mono text-3xl font-semibold text-white tracking-tight">1.08742</div>
                <div className="font-mono text-xs text-[#00ff88] mt-1 flex items-center gap-1">
                  <svg className="w-3 h-3" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2">
                    <polyline points="2,9 6,3 10,9"/>
                  </svg>
                  +0.00132 (+0.12%)
                </div>
              </div>
              <div className="text-right font-mono text-[10px] text-[#333] space-y-1 mt-1">
                <div>H: <span className="text-[#555]">1.0921</span></div>
                <div>L: <span className="text-[#555]">1.0798</span></div>
                <div>V: <span className="text-[#555]">48.2K</span></div>
              </div>
            </div>

            {/* chart */}
            <div className="h-36 px-2 pb-2">
              <AreaChart/>
            </div>

            {/* pair strip */}
            <div className="border-t border-[#1c1c1c] grid grid-cols-3 divide-x divide-[#1c1c1c]">
              {pairs.slice(0,3).map(p=>(
                <div key={p.sym} className="px-3 py-3">
                  <div className="font-mono text-[9px] text-[#333] mb-1 uppercase tracking-wider">{p.sym}</div>
                  <div className="font-mono text-xs font-medium text-white">{p.val}</div>
                  <div className={`font-mono text-[10px] mt-0.5 ${p.up?"text-[#00ff88]":"text-red-500"}`}>{p.chg}</div>
                </div>
              ))}
            </div>

            {/* stats row */}
            <div className="border-t border-[#1c1c1c] grid grid-cols-3 divide-x divide-[#1c1c1c] bg-[#080808]">
              {[
                { label:"Учеников", to:1200, suffix:"+" },
                { label:"Модулей",  to:6,    suffix:""  },
                { label:"Цена",     to:0,    suffix:" ₽"},
              ].map(s=>(
                <div key={s.label} className="px-3 py-3 text-center">
                  <div className="font-display text-xl text-[#00ff88] num-glow tracking-wider">
                    <Counter to={s.to} suffix={s.suffix}/>
                  </div>
                  <div className="font-mono text-[9px] text-[#333] uppercase tracking-wider mt-0.5">{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* bottom pairs bar */}
        <div className="border-t border-[#1c1c1c] w-full">
          <div className="max-w-7xl mx-auto px-5 md:px-12 grid grid-cols-3 md:grid-cols-6 divide-x divide-[#1c1c1c]">
            {pairs.map(p=>(
              <div key={p.sym} className="pair-item px-4 py-4 hover:bg-[#080808] transition-colors duration-200 cursor-default">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-[9px] text-[#333] uppercase tracking-wider">{p.sym}</span>
                  <Spark pts={p.pts} up={p.up}/>
                </div>
                <div className="font-mono text-sm font-semibold text-white">{p.val}</div>
                <div className={`font-mono text-[10px] mt-0.5 ${p.up?"text-[#00ff88]":"text-red-500"}`}>
                  {p.up?"▲":"▼"} {p.chg}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ PROGRAM ══ */}
      <section id="программа" className="border-t border-[#1c1c1c] py-24 px-5 md:px-12 max-w-7xl mx-auto">
        <div className="flex items-end justify-between mb-14 border-b border-[#1c1c1c] pb-8">
          <div>
            <div className="font-mono text-[#00ff88] text-[10px] uppercase tracking-[.22em] mb-3">Программа</div>
            <h2 className="font-display leading-none tracking-wider" style={{fontSize:"clamp(44px,6vw,88px)"}}>
              ЧТО ТЫ ИЗУЧИШЬ
            </h2>
          </div>
          <span className="font-display text-[88px] leading-none text-[#111] hidden md:block select-none">6</span>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-[#1c1c1c]">
          {modules.map((m,i)=>(
            <div key={m.n}
              className="bg-black p-7 md:p-9 group hover:bg-[#050505] transition-colors duration-300 cursor-default"
              style={{animationDelay:`${i*.06}s`}}
            >
              <div className="flex items-center justify-between mb-7">
                <span className="font-mono text-[38px] font-semibold text-[#111] group-hover:text-[#1c1c1c] transition-colors leading-none">
                  {m.n}
                </span>
                <div className="w-1.5 h-1.5 rounded-full bg-[#1c1c1c] group-hover:bg-[#00ff88] transition-colors duration-300"/>
              </div>
              <h3 className="font-display text-xl tracking-wider text-white mb-3 group-hover:text-[#00ff88] transition-colors duration-300">
                {m.title.toUpperCase()}
              </h3>
              <p className="text-[#444] text-sm leading-relaxed">{m.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ══ ABOUT ══ */}
      <section id="о курсе" className="border-t border-[#1c1c1c] py-24 px-5 md:px-12 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-[1fr_1fr] gap-16 lg:gap-24 items-center">
          <div>
            <div className="font-mono text-[#00ff88] text-[10px] uppercase tracking-[.22em] mb-3">О курсе</div>
            <h2 className="font-display leading-none tracking-wider mb-8" style={{fontSize:"clamp(44px,5.5vw,80px)"}}>
              НИКАКИХ<br/>КУРСОВ<br/>ЗА <span className="text-[#00ff88]">100К</span>
            </h2>
            <p className="text-[#555] text-sm md:text-base leading-relaxed mb-5">
              Я сам прошёл путь от нуля до стабильного трейдера. Знаю, как легко потерять деньги без знаний — и как сложно найти честное обучение без обещаний «лёгких денег».
            </p>
            <p className="text-[#555] text-sm md:text-base leading-relaxed mb-10">
              Делюсь всем бесплатно: стратегиями, разборами сделок, ответами на вопросы. Мне важен твой результат.
            </p>
            <a href={TG_LINK} target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 font-mono text-xs text-[#00ff88] uppercase tracking-widest group">
              Написать мне
              <span className="group-hover:translate-x-1.5 transition-transform duration-200">→</span>
            </a>
          </div>

          <div className="grid grid-cols-2 gap-px bg-[#1c1c1c]">
            {[
              { icon:"◈", title:"Реальные примеры",   desc:"Разбираем сделки с реального рынка, не выдуманные кейсы" },
              { icon:"⚡", title:"Быстрый старт",      desc:"Применяешь знания уже после первого модуля на демо-счёте" },
              { icon:"◉", title:"Без рисков",          desc:"Начинаем на демо — учимся без потери реальных денег" },
              { icon:"◌", title:"Личная поддержка",    desc:"Отвечаю на вопросы лично в удобном мессенджере" },
            ].map(f=>(
              <div key={f.title} className="bg-black p-6 group hover:bg-[#050505] transition-colors duration-200 cursor-default">
                <div className="text-[#00ff88] text-xl mb-4">{f.icon}</div>
                <div className="font-mono text-[10px] text-white uppercase tracking-widest mb-2">{f.title}</div>
                <div className="text-[#444] text-xs leading-relaxed">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ FAQ ══ */}
      <section id="faq" className="border-t border-[#1c1c1c] py-24 px-5 md:px-12 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-[260px_1fr] gap-16">
          <div>
            <div className="font-mono text-[#00ff88] text-[10px] uppercase tracking-[.22em] mb-3">FAQ</div>
            <h2 className="font-display leading-none tracking-wider" style={{fontSize:"clamp(36px,4vw,64px)"}}>
              ЧАСТЫЕ<br/>ВОПРОСЫ
            </h2>
          </div>
          <div className="border-t border-[#1c1c1c]">
            {faqs.map(f=><Faq key={f.q} q={f.q} a={f.a}/>)}
          </div>
        </div>
      </section>

      {/* ══ CONTACT ══ */}
      <section id="контакт" className="border-t border-[#1c1c1c]">
        <div className="max-w-7xl mx-auto px-5 md:px-12 py-24">

          {/* big heading */}
          <div className="text-center mb-20">
            <div className="font-mono text-[#00ff88] text-[10px] uppercase tracking-[.22em] mb-4">Контакт</div>
            <h2 className="font-display leading-none tracking-wider" style={{fontSize:"clamp(56px,11vw,160px)"}}>
              НАПИШИ<br/><span className="text-[#00ff88]">МНЕ</span>
            </h2>
            <p className="text-[#444] text-sm mt-8 max-w-xs mx-auto leading-relaxed">
              Напиши{" "}
              <span className="font-mono text-white bg-[#0d0d0d] border border-[#1c1c1c] px-2 py-0.5">
                «Хочу учиться»
              </span>{" "}
              — отвечу быстро
            </p>
          </div>

          {/* two cards */}
          <div className="grid sm:grid-cols-2 gap-px bg-[#1c1c1c] max-w-2xl mx-auto">
            <a href={TG_LINK} target="_blank" rel="noopener noreferrer"
              className="group bg-black p-10 md:p-14 flex flex-col gap-7 hover:bg-[#050505] transition-colors duration-300">
              <svg className="w-12 h-12 text-[#0088cc]" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.1 13.137 4.17 12.26c-.657-.204-.669-.657.136-.975l10.97-4.23c.547-.194 1.026.13.618.166z"/>
              </svg>
              <div>
                <div className="font-display text-4xl tracking-wider text-white group-hover:text-[#0088cc] transition-colors duration-300">TELEGRAM</div>
                <div className="font-mono text-xs text-[#444] mt-1.5">@Lonyyyvip</div>
              </div>
              <div className="flex items-center gap-2 font-mono text-xs text-[#00ff88] uppercase tracking-widest">
                Написать <span className="group-hover:translate-x-1.5 transition-transform duration-200 inline-block">→</span>
              </div>
            </a>

            <a href={MAX_LINK} target="_blank" rel="noopener noreferrer"
              className="group bg-black p-10 md:p-14 flex flex-col gap-7 hover:bg-[#050505] transition-colors duration-300">
              <div className="w-12 h-12 border border-[#00ff88] flex items-center justify-center group-hover:bg-[#00ff88]/10 transition-colors duration-300">
                <svg className="w-6 h-6 text-[#00ff88]" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20 2H4C2.9 2 2 2.9 2 4v16l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
                </svg>
              </div>
              <div>
                <div className="font-display text-4xl tracking-wider text-white group-hover:text-[#00ff88] transition-colors duration-300">MAX</div>
                <div className="font-mono text-xs text-[#444] mt-1.5">Мессенджер МАХ</div>
              </div>
              <div className="flex items-center gap-2 font-mono text-xs text-[#00ff88] uppercase tracking-widest">
                Написать <span className="group-hover:translate-x-1.5 transition-transform duration-200 inline-block">→</span>
              </div>
            </a>
          </div>
        </div>
      </section>

      {/* ══ FOOTER ══ */}
      <footer className="border-t border-[#1c1c1c] py-8 px-5 md:px-12">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <Logo size="sm"/>
          <p className="font-mono text-[#2a2a2a] text-[10px] uppercase tracking-widest">
            Бесплатное обучение · Форекс · Трейдинг
          </p>
          <div className="flex gap-7">
            <a href={TG_LINK} target="_blank" rel="noopener noreferrer"
              className="font-mono text-[#333] text-[10px] uppercase tracking-widest hover:text-[#00ff88] transition-colors">TG</a>
            <a href={MAX_LINK} target="_blank" rel="noopener noreferrer"
              className="font-mono text-[#333] text-[10px] uppercase tracking-widest hover:text-[#00ff88] transition-colors">MAX</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
